## Backups Folder

This folder is used to store backups for the PiFire Settings and Pellet Database.  Backups can be saved and restored from this folder in the Admin page in the PiFire UI.